# Change Log

Font Awesome 6 is here! And with it a new location for the change log.

Visit https://fontawesome.com/docs/changelog/.
